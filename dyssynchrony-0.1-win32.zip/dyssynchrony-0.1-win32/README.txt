Dyssyncrony Version 1.0 - README
================================

This program calculates strain angles for measuring cardiac dyssynchrony
from both VevoStrain and TomTec speckle tracking strain measurements.

To use it run the program "gui.exe". Use the + sign at the bottom to add
your measurements, choose a file to "Save as..." and click Go. 

The program will output a Comma Seperated Value (CSV) file that will open
in Spreadsheet programs (such as Microsoft Excel). 

For Questions please contact: Michael Bauer <mihi@tentacleriot.eu>

This Program is free open source software distributed with a BSD license -
see the file LICENSE for details.
